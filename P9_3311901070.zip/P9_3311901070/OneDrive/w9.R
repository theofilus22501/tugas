lokasi_kerja <- "D:/OneDrive"
setwd(lokasi_kerja)
getwd()

dataset <- read.csv("w9.csv", sep = ";")
head(dataset)

install.packages("C50")
install.packages("printr")

library(C50)
library(printr)

class(dataset)
class(dataset$age)
class(dataset$buys_computer)

dataset$buys_computer <- as.factor(dataset$buys_computer)

model <- C5.0(buys_computer ~., data = dataset)
model
summary(model)

plot(model)

datatesting <- dataset[,1:4]

predictions <- predict(model, datatesting)
table(predictions, dataset$buys_computer)

